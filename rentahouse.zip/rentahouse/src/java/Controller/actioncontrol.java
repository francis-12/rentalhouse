
package Controller;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class actioncontrol {
    private String a="hello";

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }
  public void isselected()
  { a="hi";
      System.out.println("Clicked");
  }
  public void setA()
  {
      
  }
}
