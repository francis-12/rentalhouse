/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Booking;
import Model.Customer;
import Model.uploads;
import Repository.Bookingdao;
import Repository.Customerdao;
import Repository.uploaddao;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

/**
 *
 * @author Eng Michael
 */
@ManagedBean
@ApplicationScoped
public class customerbean {
   private Customer customer=new Customer();
   private Customerdao dao=new Customerdao();
   private uploaddao uploaddao=new uploaddao();
   private int myuploads=0;
   private Booking booking=new Booking();
  private Bookingdao bookingdao=new Bookingdao();
  private List<Booking> allmybooking=getAllbooking();
    public Booking getBooking() {
        return booking;
    }
//my uploads
    public int getMyuploads() {
        myuploads=0;
        getAlluploads();
        return myuploads;
    }
    public Customer getCustomer() {
        return customer;
    }
   public void saveCustomer()
   {
       dao.saveCustomer(customer);
   }
   public String login() throws IOException
   {
   List<Customer> cus= dao.login(customer.getEmail(), customer.getPassword());
      if(cus.isEmpty()){
    FacesContext.getCurrentInstance().addMessage(null,new FacesMessage("Credential not match try A gain"));
       return "login";
      }else{
        FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/rentahouse/faces/Home/tryall.xhtml");
          customer=cus.get(0);
       return "home";
      }
      
   }
   public void updatecustomer()
      {
          dao.updateCustomer(customer);
      }
   public String deleteaccount()
   {
       dao.deleteCustomer(customer);
       return "deletedaccount";
   }
   public String LogOut() throws IOException
   { FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Log out Sucessfully"));
       ExternalContext context=FacesContext.getCurrentInstance().getExternalContext();
       context.redirect("http://localhost:8080/rentahouse/faces/Home/logout.xhtml");
       return "logout";
   }
   private List<uploads>Myuploads=new ArrayList<>();
   public List<uploads>getDisplayMyuploads()
   {
       return Myuploads;
   }
   public List<uploads>getAlluploads()
   {   List<uploads>getall=uploaddao.getAll();
       for(uploads u:getall)
       {
           if(customer.getEmail().equals(u.getCustomerId().getEmail()))
           { myuploads++;
          Myuploads.add(u);
           }
       }
       return getall;
   }
//   Booking
   public void savebooking(){
       bookingdao.saveBooking(booking);
   }
   public List<Booking> getAllbooking(){  
      return bookingdao.getAll();
   }
//   My bookings
   public List<Booking> getMyBooking(){
    List<Booking> getmybooking=new ArrayList<>(); 
    for(Booking i:bookingdao.getAll())
        if(customer.getEmail().equalsIgnoreCase(i.getCustomerId().getEmail())){
            getmybooking.add(i);
           System.out.println(customer.getEmail()+i.getCustomerId().getEmail());
        }
    return getmybooking;
   }
//   View My Uploads
   public void chat() throws IOException
   {
       FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/rentahouse/faces/Home/Chat.xhtml");
   }
    
//   Delete my booking
   public void Deletebooking(Booking bk){bookingdao.deleteBooking(bk);}
   
   public void addbooking(uploads upl)
   {  
//      System.out.println(upl.getCustomerId().getEmail());
     Booking b=new Booking(); 
     Date date = new Date();
     uploadbean upload=new uploadbean();
      b.setCustomerId(customer);
      b.setDateToday(date);
      b.setHousepnumber(upl);
      bookingdao.saveBooking(b);
      upl.setIsTaken(true);
      uploaddao.updateuploads(upl);
   }
}
