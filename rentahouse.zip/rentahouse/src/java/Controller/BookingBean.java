
package Controller;

import Model.Booking;
import Repository.Bookingdao;
import java.util.List;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

@ManagedBean
@ApplicationScoped
public class BookingBean {
 private Booking book=new Booking();
 private Bookingdao dao=new Bookingdao();

 public Booking getBook() {return book;}
 private void saveBooking(){   dao.saveBooking(book);}
 public List<Booking> getAllbooking(){return  dao.getAll();}
    
}
