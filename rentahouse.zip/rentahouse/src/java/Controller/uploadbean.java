/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Customer;
import Model.Location;
import Model.uploads;
import Repository.uploaddao;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import org.primefaces.model.file.UploadedFile;
//import org.primefaces.model.file.UploadedFile;

/**
 *
 * @author Eng Michael
 */
@ManagedBean
@ApplicationScoped
public class uploadbean {
   private uploads upload=new uploads();
   private uploaddao dao=new uploaddao();
   private Location location=new Location();
   private Customer customer=new Customer();

    public Location getLocation() {
        return location;
    }

    public Customer getCustomer() {
        return customer;
    }
   private UploadedFile file1;
   private UploadedFile file2;
    public uploads getUpload() {
        return upload;
    }
    public UploadedFile getFile1() {
        return file1;
    }

    public void setFile1(UploadedFile file1) {
        this.file1 = file1;
    }

    public UploadedFile getFile2() {
        return file2;
    }

    public void setFile2(UploadedFile file2) {
        this.file2 = file2;
    }
   public void saveupload() throws FileNotFoundException, IOException
   {
//           FileInputStream in=new FileInputStream(file1.getFileName());
//    FileInputStream in2=new FileInputStream(file1.getFileName());
//    byte[] img1=new byte[in.available()];
//    in.read(img1);
//    byte[] img2=new byte[in2.available()];
//    in2.read(img2);
    uploads up1=new uploads();
    up1.setBedroom(upload.getBedroom());
    up1.setCell(location);
//    up1.setImage1(file1.getContent());
//    up1.setImage2(file2.getContent());
    up1.setIsTaken(false);
    up1.setKitchen(upload.getKitchen());
    up1.setPlotNumber(upload.getPlotNumber());
    up1.setToilet(upload.getToilet());
    up1.setCustomerId(customer);
    dao.saveuploads(up1);
   }
//   DisplayAll
   public List<uploads> getAlluploads()
   { 
       return dao.getAll();
   }
   
   
}
