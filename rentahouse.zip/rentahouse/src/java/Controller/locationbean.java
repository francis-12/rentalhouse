/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Location;
import Repository.LocationDao;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class locationbean {
  private Location location=new Location();
  private LocationDao dao=new LocationDao();
  private boolean action=false;
  private List<Location>allocation=getAll();
    public Location getLocation() {
        return location;
    }

 public void saveLocation()
 {
     dao.saveLocation(location);
 }
 public List<Location>getAll()
 {
     return dao.getAll();
 }
 public List<Location>getProvince()
 {List<Location>province=new ArrayList<>();
     for(Location i:allocation)
     {        if(i.getParentname().equals("PROVINCE"))
             province.add(i);
     }
     return province;
 }
 
 public List<Location>getDistrict()
 {List<Location>districts=new ArrayList<>();
     for(Location i:allocation)
     {
         if(i.getParentname().equals("DISTRICT")&&action==false)
             districts.add(i);
         else if(i.getParentname().equals("DISTRICT")&&action==true&&location.getId().equals(i.getParentid()))
             districts.add(i);
     }
     return districts;
 }
  public List<Location>getSector()
 {List<Location>sector=new ArrayList<>();
     for(Location i:allocation)
     {
         if(i.getParentname().equals("SECTOR") && action==false)
             sector.add(i);
          else if(i.getParentname().equals("SECTOR")&&action==true&&location.getId().equals(i.getParentid()))
             sector.add(i);
     }
     return sector;
 }
    public List<Location>getCell()
 {List<Location>cell=new ArrayList<>();
     for(Location i:allocation)
     {
         if(i.getParentname().equals("CELL")&&action==false)
             cell.add(i);
         else if(i.getParentname().equals("CELL")&&action==true&&location.getId().equals(i.getParentid()))
             cell.add(i);
     }
     return cell;
 }
    public static void main(String[] args) {
        locationbean loc=new locationbean();
        for(Location i:loc.getDistrict())
        {
            System.out.println(i.getName());
        }
    }
//    action happened
    public void actionProvince()
    {System.out.println(location.getId());
        action=true;
    }
}
