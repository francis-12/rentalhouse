
package Controller;

import Model.uploads;
import Repository.uploaddao;
import java.io.ByteArrayInputStream;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

@ManagedBean
@ViewScoped
public class ImageBean {

  @Inject
  private uploaddao imageService;

  private List<uploads> images;

  @PostConstruct
  public void init() {
    images = imageService.getAll();
  }

//  public List<uploads> getImages() {
//    return images;
//  }
//
//  public StreamedContent getImageData(uploads image) {
//    return new DefaultStreamedContent(new ByteArrayInputStream(image.getImage1()));
//  }

}
