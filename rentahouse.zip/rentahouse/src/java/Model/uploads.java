package Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cacheable(value = true)
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class uploads implements Serializable {
    @Id
   private String plotNumber;
   private boolean isTaken;
   @ManyToOne(fetch = FetchType.EAGER)
   private Location cell;
   private int Bedroom;
   private int Kitchen;
   private int toilet;
   @ManyToOne(fetch = FetchType.EAGER)
   private Customer customerId;
   @Column(columnDefinition = "longBlob")
   private byte[] image1;
   @Column(columnDefinition = "longBlob")
   private byte[] image2;
   @OneToMany(mappedBy = "housepnumber")
   private List<Booking> bookings;
   private double  cost;

    public List<Booking> getBookings() {
        return bookings;
    }

    public void setBookings(List<Booking> bookings) {
        this.bookings = bookings;
    }
   
    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
    public String getPlotNumber() {
        return plotNumber;
    }

    public void setPlotNumber(String plotNumber) {
        this.plotNumber = plotNumber;
    }

    public boolean isIsTaken() {
        return isTaken;
    }

    public void setIsTaken(boolean isTaken) {
        this.isTaken = isTaken;
    }

    public Location getCell() {
        return cell;
    }

    public void setCell(Location cell) {
        this.cell = cell;
    }

    public int getBedroom() {
        return Bedroom;
    }

    public void setBedroom(int Bedroom) {
        this.Bedroom = Bedroom;
    }

    public int getKitchen() {
        return Kitchen;
    }

    public void setKitchen(int Kitchen) {
        this.Kitchen = Kitchen;
    }

    public int getToilet() {
        return toilet;
    }

    public void setToilet(int toilet) {
        this.toilet = toilet;
    }

    public Customer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Customer customerId) {
        this.customerId = customerId;
    }

    public byte[] getImage1() {
        return image1;
    }

    public void setImage1(byte[] image1) {
        this.image1 = image1;
    }

    public byte[] getImage2() {
        return image2;
    }

    public void setImage2(byte[] image2) {
        this.image2 = image2;
    }
}
