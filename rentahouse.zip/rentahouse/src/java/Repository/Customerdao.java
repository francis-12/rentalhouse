
package Repository;

import Controller.customerbean;
import Model.Customer;
import Model.Location;
import Utilclass.Hibernateconnector;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.hibernate.CacheMode;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Eng Michael
 */
public class Customerdao {
    public void saveCustomer(Customer loc)
   {
      try{ Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.save(loc);
       ss.beginTransaction().commit();
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Credential Saved Sucessfully"));
      }catch(Exception e)
      {
          FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Credential Already Exist"));
      }
   }
    public void updateCustomer(Customer loc)
   {
      try{ Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.update(loc);
       ss.beginTransaction().commit();
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Credential Updated Sucessfully"));
      }catch(Exception e)
      {
          FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Credential Doesn't Exist"));
      }
   }
    public void deleteCustomer(Customer loc)
   {
      try{ Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.delete(loc);
       ss.beginTransaction().commit();
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Account Deleted Sucessfully"));
      }catch(Exception e)
      {
          FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Account Doesn't Exist"));
      }
   } 
   public List<Customer> login(String email,String passwd)
   { Session ss=Hibernateconnector.getSessionFactory().openSession();
       Query q=ss.createQuery("from Customer where Email=:e and password=:p");
       q.setParameter("e", email);
       q.setParameter("p", passwd);
       q.setCacheable(true);
       List<Customer>customer=q.list();
       ss.close();
       return customer;
   }
     public static void main(String[] args) {
        Customerdao d=new Customerdao();
       List<Customer>c= d.login("i", "i");
       for(Customer i:c)
             System.out.println(i.getNames());
    }
}
