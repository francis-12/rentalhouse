package Repository;

import Model.Booking;
import Utilclass.Hibernateconnector;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Eng Michael
 */
public class Bookingdao {
   public  void saveBooking(Booking b)
   {
       try{ Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.save(b);
       ss.beginTransaction().commit();
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Booking Saved Sucessfully"));
      }catch(Exception e)
      {
          FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Booking Already Taken"));
      }
   }
    public  void deleteBooking(Booking b)
   {
       try{ Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.delete(b);
       ss.beginTransaction().commit();
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Booking Deleted Sucessfully"));
      }catch(Exception e)
      {
          FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Deleted Already Taken"));
      }
   }
    public  List<Booking> getAll()
   {
        Session ss=Hibernateconnector.getSessionFactory().openSession();
        Query booking=ss.createQuery("from Booking");
        booking.setCacheable(true);
        List<Booking>book=booking.list();
        return book;
   }
}
