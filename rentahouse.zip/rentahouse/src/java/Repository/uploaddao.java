/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Repository;

import Model.Customer;
import Model.uploads;
import Utilclass.Hibernateconnector;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Eng Michael
 */
public class uploaddao {
      public void saveuploads(uploads up)
   {
      try{ Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.save(up);
       ss.beginTransaction().commit();
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Upload Saved Sucessfully"));
      }catch(Exception e)
      {
          FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Land Already Exist"));
      }
   }
    public void updateuploads(uploads upl)
   {
      try{ Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.update(upl);
       ss.beginTransaction().commit();
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Upload Updated Sucessfully"));
      }catch(Exception e)
      {
          FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e+""));
      }
   }
    public void deleteuploads(uploads loc)
   {
      try{ Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.delete(loc);
       ss.beginTransaction().commit();
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Upload Deleted Sucessfully"));
      }catch(Exception e)
      {
          FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Upload Doesn't Exist"));
      }
   } 
   public List<uploads> getAll()
   { Session ss=Hibernateconnector.getSessionFactory().openSession();
       Query q=ss.createQuery("from uploads"); 
       List<uploads>Uploads=q.list();
       ss.close();
       return Uploads;
   }
}
