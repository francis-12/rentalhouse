
package Repository;

import Model.Location;
import Utilclass.Hibernateconnector;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

public class LocationDao {
   public void saveLocation(Location loc)
   {
       Session ss=Hibernateconnector.getSessionFactory().openSession();
       ss.save(loc);
       ss.beginTransaction().commit();
       
   }
   public List<Location> getAll()
   { Session ss=Hibernateconnector.getSessionFactory().openSession();
       Query q=ss.createQuery("from Location");
       q.setCacheable(true);
       List<Location> getall=q.list();
       ss.close();
       return getall;
   }
}
